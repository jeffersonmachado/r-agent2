# Sistema de Fallback - Documentação Técnica

## Visão Geral

O sistema de fallback do r-agent2 é um mecanismo centralizado e progressivo que garante que nenhum fluxo falhe silenciosamente. Ele detecta erros, controla tentativas e escala para atendimento humano quando necessário.

## Arquitetura

### Componentes Principais

1. **FallbackController** (`frontend/src/core/FallbackController.js` / `engine/fallbackController.js`)
   - Ponto único de decisão de fallback
   - Stateless por chamada (estado via contexto)
   - Decide ação: retry, options, human, end

2. **FallbackNode** (`frontend/src/editor/nodeSchemas.js`)
   - Nó visual no editor
   - Entradas: in, error, timeout, no_match
   - Saídas: retry, options, human, end

3. **flowValidator** (`frontend/src/editor/flowValidator.js`)
   - Validação estrutural obrigatória
   - Garante que todo fluxo tenha FallbackNode

4. **fallbackNodeHandler** (`engine/nodes/fallbackNode.js`)
   - Handler de execução do FallbackNode
   - Delega decisões ao FallbackController

5. **HumanEscalationAdapter** (`engine/services/humanEscalationAdapter.js`)
   - Interface genérica de escalada humana
   - Desacoplada de canal específico

## Como Funciona no Editor

### Criando um Fluxo com Fallback

1. **Adicione um FallbackNode ao fluxo**
   - O fluxo DEVE conter pelo menos 1 FallbackNode
   - Validação estrutural obrigatória

2. **Configure o FallbackNode**
   - `maxAttempts`: Máximo de tentativas (padrão: 3)
   - `confidenceThreshold`: Threshold de confiança (padrão: 0.75)
   - `enableEmotionCheck`: Detectar frustração (padrão: true)
   - `safeReturnNode`: Nó para retorno após escalada humana (opcional)

3. **Conecte entradas de erro**
   - Nós com `errorPorts: true` podem conectar saída de erro ao FallbackNode
   - Nós com `supportsTimeout: true` podem conectar timeout ao FallbackNode

4. **Conecte saídas do FallbackNode**
   - `retry`: Nó para tentar novamente
   - `options`: Nó para oferecer opções ao usuário
   - `human`: Nó de escalada humana
   - `end`: Nó de encerramento

### Validação

O botão "Validar" executa:
1. Validação local de fallback (flowValidator)
2. Validação do backend (engine/validator.js)

**Erros comuns:**
- `NO_FALLBACK_NODE`: Fluxo sem FallbackNode
- `ORPHAN_NODE`: Nó desconectado
- `PATH_WITHOUT_TERMINATION`: Caminho sem término adequado

## Como Funciona no Runtime

### Fluxo de Execução

1. **Erro detectado**
   - Durante execução, qualquer erro gera evento:
     - `intent_error`: Intenção não reconhecida
     - `flow_error`: Erro no fluxo
     - `data_error`: Erro de dados
     - `timeout`: Timeout
     - `no_match`: Sem correspondência

2. **Evento encaminhado ao FallbackNode**
   - Input contém: `fallbackType`, `error`, `userMessage`

3. **FallbackController processa**
   - Cria contexto de fallback
   - Detecta loops e frustração
   - Decide ação baseada em tentativas

4. **Ação executada**
   - `retry`: Volta ao nó configurado
   - `options`: Oferece opções ao usuário
   - `human`: Escala para atendimento humano
   - `end`: Encerra conversa

### Limite de Tentativas

- Máximo de 3 tentativas por padrão (configurável)
- Contagem por nó específico
- Após 3 tentativas, escalada automática para humano

### Detecção de Loops

- Detecta quando mesmo nó aciona fallback 2+ vezes nas últimas 3 ocorrências
- Escala imediatamente para humano quando detectado

### Detecção de Frustração

- Palavras-chave: "não entendi", "não funciona", "erro", etc.
- Escala imediatamente para humano quando detectado

## Escalada Humana

### Interface do Adapter

```javascript
const adapter = new HumanEscalationAdapter();

// Escalar para humano
await adapter.escalateToHuman({
  sessionId: 'session-123',
  flowId: 'flow-456',
  reason: 'intent',
  attempt: 3,
  history: [...],
  variables: {...},
  safeReturnNode: 'node-789',
});

// Verificar se pode retornar
const canReturn = await adapter.canReturnToBot('session-123');

// Retornar ao bot
await adapter.returnToBot('session-123', 'node-789');
```

### Implementação

A implementação real deve ser fornecida pelo sistema que usa a engine. O adapter padrão (`DefaultHumanEscalationAdapter`) é apenas para desenvolvimento/testes.

## Observabilidade

### Logs Estruturados

Eventos de fallback são logados via `logger.event()`:

```javascript
logger.event('fallback_triggered', {
  fallbackType: 'intent',
  attempt: 1,
  nodeId: 'node-123',
  sessionId: 'session-456',
  action: 'retry',
  timestamp: '2025-12-30T12:00:00.000Z',
  hasLoop: false,
  hasFrustration: false,
});
```

### Eventos Disponíveis

- `fallback_triggered`: Fallback acionado
- `fallback_loop_detected`: Loop detectado
- `fallback_frustration_detected`: Frustração detectada
- `fallback_max_attempts_reached`: Máximo de tentativas atingido

### Visualização

O componente `FallbackEventsViewer` exibe eventos recentes de fallback no editor.

## Boas Práticas

### Criando Fluxos Seguros

1. **Sempre inclua FallbackNode**
   - Todo fluxo DEVE ter pelo menos 1 FallbackNode
   - Conecte todos os caminhos de erro ao FallbackNode

2. **Configure tentativas adequadamente**
   - 3 tentativas é um bom padrão
   - Ajuste baseado na complexidade do fluxo

3. **Use nó de retorno seguro**
   - Configure `safeReturnNode` para permitir retorno após escalada humana

4. **Teste cenários de erro**
   - Simule erros de intenção
   - Simule timeouts
   - Simule erros de dados

5. **Monitore eventos de fallback**
   - Use `FallbackEventsViewer` para monitorar
   - Analise padrões de erro

### Evitando Loops

- Não conecte FallbackNode diretamente a si mesmo
- Use nós intermediários para retry
- Configure `safeReturnNode` adequadamente

### Escalada Humana

- Configure `safeReturnNode` para permitir retorno
- Mantenha contexto completo durante escalada
- Permita retorno controlado ao bot

## Regras Obrigatórias

1. ✅ **Nenhum fluxo é válido sem FallbackNode**
2. ✅ **Todo erro passa pelo FallbackController**
3. ✅ **Máximo de 3 tentativas (configurável)**
4. ✅ **Nenhum erro técnico visível ao usuário final**
5. ✅ **Escalada humana preserva contexto**
6. ✅ **Atendimento humano permite retorno ao bot**

## Troubleshooting

### Fallback não está sendo acionado

- Verifique se o fluxo tem FallbackNode
- Verifique se as conexões de erro estão corretas
- Verifique logs para eventos de erro

### Loop infinito

- Verifique se FallbackNode não está conectado a si mesmo
- Verifique histórico de fallbacks no estado
- Use `safeReturnNode` para quebrar loops

### Escalada humana não funciona

- Verifique se adapter está implementado
- Verifique se `safeReturnNode` está configurado
- Verifique logs para erros de escalada

## Referências

- `PROJECT_RULES.md`: Regras gerais do projeto
- `frontend/src/core/FallbackController.js`: Controller do frontend
- `engine/fallbackController.js`: Controller da engine
- `engine/nodes/fallbackNode.js`: Handler do FallbackNode
- `engine/services/humanEscalationAdapter.js`: Adapter de escalada humana

