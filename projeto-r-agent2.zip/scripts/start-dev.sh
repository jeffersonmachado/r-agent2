#!/bin/bash

# Script para iniciar API e Frontend juntos em desenvolvimento

# Cores para output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${BLUE}Iniciando servidores de desenvolvimento...${NC}"

# Função para verificar se porta está em uso
check_port() {
    local port=$1
    if lsof -Pi :$port -sTCP:LISTEN -t >/dev/null 2>&1 || fuser $port/tcp >/dev/null 2>&1; then
        return 0  # Porta em uso
    else
        return 1  # Porta livre
    fi
}

# Função para limpar processos ao sair
cleanup() {
    echo -e "\n${BLUE}Parando servidores...${NC}"
    kill $API_PID $FRONTEND_PID 2>/dev/null
    exit
}

trap cleanup SIGINT SIGTERM

# Verifica se a porta 3000 está em uso
if check_port 3000; then
    echo -e "${YELLOW}Aviso: Porta 3000 já está em uso${NC}"
    echo -e "${YELLOW}Verificando se é a API do projeto...${NC}"
    
    # Tenta encontrar o processo
    API_PROCESS=$(ps aux | grep "node.*server.js" | grep -v grep | awk '{print $2}' | head -1)
    
    if [ -n "$API_PROCESS" ]; then
        echo -e "${GREEN}API já está rodando (PID: $API_PROCESS)${NC}"
        echo -e "${BLUE}Usando API existente...${NC}"
        API_PID=$API_PROCESS
        USE_EXISTING_API=true
    else
        echo -e "${RED}Erro: Porta 3000 está em uso por outro processo${NC}"
        echo -e "${YELLOW}Execute: lsof -ti:3000 | xargs kill${NC}"
        echo -e "${YELLOW}Ou use uma porta diferente: API_PORT=3001 npm run dev${NC}"
        exit 1
    fi
else
    # Inicia a API em background
    echo -e "${GREEN}Iniciando API na porta 3000...${NC}"
    node api/server.js &
    API_PID=$!
    USE_EXISTING_API=false
    
    # Aguarda um pouco para a API iniciar
    sleep 2
    
    # Verifica se a API está rodando
    if ! kill -0 $API_PID 2>/dev/null; then
        echo -e "${RED}Erro: API não iniciou corretamente${NC}"
        exit 1
    fi
fi

# Inicia o frontend
echo -e "${GREEN}Iniciando Frontend na porta 5173...${NC}"
cd frontend
npm start &
FRONTEND_PID=$!
cd ..

echo -e "${BLUE}Servidores iniciados!${NC}"
echo -e "${GREEN}API: http://localhost:3000${NC}"
echo -e "${GREEN}Frontend: http://localhost:5173${NC}"

if [ "$USE_EXISTING_API" = true ]; then
    echo -e "${YELLOW}Aviso: API já estava rodando. Não será parada ao pressionar Ctrl+C${NC}"
    echo -e "${BLUE}Pressione Ctrl+C para parar apenas o frontend${NC}"
    wait $FRONTEND_PID
else
    echo -e "${BLUE}Pressione Ctrl+C para parar ambos os servidores${NC}"
    wait
fi

