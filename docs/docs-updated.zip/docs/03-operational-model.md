# Modelo Operacional

``` mermaid
flowchart LR
Events --> Signals --> Recommendations --> Decision --> Execution["Action / Quick Action / Playbook"] --> Outcomes --> OperationalMemory["Operational Memory"]
```

## Fluxo canônico

`EVENTO -> SINAL -> RECOMENDAÇÃO -> DECISÃO -> AÇÃO / AÇÃO RÁPIDA / PLAYBOOK -> RESULTADO -> MEMÓRIA OPERACIONAL`

## Expectativas de domínio

- Toda execução operacional relevante deve terminar em um `Resultado (Outcome)`
- Todo `Resultado (Outcome)` deve ser elegível para alimentar a `Memória Operacional (Operational Memory)`
- `Ações Rápidas (Quick Actions)` são a borda de execução rápida do mesmo modelo operacional, não uma arquitetura paralela
- `Playbooks` são execuções operacionais orquestradas dentro do mesmo ciclo canônico
- Visões de OCC e suporte devem expor esse ciclo, sem inventar semânticas alternativas de domínio

## Agendamento Autônomo (Primeiro Domínio Autônomo)

Agendamento Autônomo (Autonomous Scheduling) é o primeiro domínio em produção no qual o modelo operacional canônico roda como operação autônoma de ciclo fechado.

Fluxo operacional:

`booking.cancelled -> detecção de lacuna -> geração de candidatos -> ranking -> campanha/oferta -> agendamento confirmado`

Interpretação no ciclo canônico:

- `booking.cancelled` e o contexto relacionado são observados como eventos operacionais
- o gap e o contexto de candidatos são projetados como estado operacional
- ranking e seleção de políticas produzem uma decisão (Próxima Melhor Ação / Next Best Action)
- campanhas/ofertas executam por meio do runtime operacional
- confirmação (ou falha) de booking é registrada como resultado (outcome) e alimenta a memória operacional

## Loop autônomo de operações

Além do fluxo canônico, o modelo operacional também deve ser lido como:

`Observar -> Projetar Estado -> Decidir -> Executar -> Aprender`

### Observar

O sistema observa eventos operacionais como:

- `conversation.received`
- `ticket.created`
- `booking.cancelled`
- `booking.gap_detected`
- `contact.reactivation_due`
- `sla.risk_detected`
- `order.delayed`

### Projetar Estado

Os eventos são transformados em projeções de estado operacional, por exemplo:

- estado do contato
- estado do ticket
- estado da agenda
- estado da fila
- estado da oportunidade
- estado do atendimento
- estado operacional por profissional/unidade

### Decidir

A camada de decisão usa essas projeções para escolher a **Próxima Melhor Ação**, como:

- priorização de ticket
- sugestão de resposta
- reativação de contato
- oferta de horário
- redistribuição de fila
- otimização de agenda
- ações de revenue

### Executar

As decisões são executadas por meio de:

- actions
- quick actions
- playbooks
- flows
- BPMN
- integrações e serviços de domínio

### Aprender

O fechamento do loop ocorre quando:

- resultados são registrados
- decisões ficam auditáveis
- feedback de recomendações é persistido
- a memória operacional passa a aprender com os efeitos reais da execução
