import { useRete } from 'rete-react-plugin';
import { useEffect, useRef, forwardRef, useImperativeHandle } from 'react';
import { AreaExtensions } from 'rete-area-plugin';

import { createEditor } from './editor/createEditor';
import logger from './utils/logger';

/**
 * Componente FlowEditor usando useRete hook seguindo o padrão do reference.
 * 
 * O hook useRete gerencia automaticamente o ciclo de vida do editor:
 * - Criação quando o componente é montado
 * - Cleanup quando o componente é desmontado
 * - Re-criação quando as dependências mudam
 */
export const FlowEditor = forwardRef(function FlowEditor({
  initialFlowJson,
  onFlowChanged,
  onNodeSelected
}, ref) {
  const editorInstanceRef = useRef(null);
  const previousFlowJsonRef = useRef(null);
  
  // Usa useRete hook seguindo o padrão do reference
  // O hook gerencia automaticamente o ciclo de vida (criação e cleanup)
  const [containerRef, editorInstance] = useRete(async (container) => {
    return await createEditor(container, {
      initialFlowJson,
      onFlowChanged,
      onNodeSelected,
    });
  });

  // Guarda referência do editor para uso externo
  useEffect(() => {
    if (editorInstance) {
      editorInstanceRef.current = editorInstance;
    }
  }, [editorInstance]);

  // Expõe editor e area através da ref (para compatibilidade com FlowEditorPage)
  useImperativeHandle(ref, () => {
    const instance = editorInstanceRef.current;
    if (!instance) return null;
    
    return {
      editor: { current: instance.editor },
      area: instance.area,
      // Métodos auxiliares para compatibilidade
      zoomToFit: () => {
        if (instance.area && instance.editor) {
          const nodes = instance.editor.getNodes();
          if (nodes.length > 0) {
            try {
              AreaExtensions.zoomAt(instance.area, nodes);
            } catch (err) {
              logger.warn('Erro ao fazer zoom', { error: err });
            }
          }
        }
      },
    };
  }, [editorInstance]);

  // Carrega fluxo quando initialFlowJson muda (após inicialização)
  useEffect(() => {
    const editorInstance = editorInstanceRef.current;
    if (!editorInstance || !initialFlowJson) return;

    // Evita recarregar se o JSON não mudou
    const currentJsonStr = JSON.stringify(initialFlowJson);
    const previousJsonStr = previousFlowJsonRef.current;
    if (currentJsonStr === previousJsonStr) return;
    previousFlowJsonRef.current = currentJsonStr;

    const { editor } = editorInstance;
    if (!editor) return;

    // Limpa nós existentes antes de carregar novo fluxo
    editor.clear();

    logger.debug('Carregando fluxo do JSON (atualização)', {
      hasJson: !!initialFlowJson,
      nodeCount: initialFlowJson?.nodes ? Object.keys(initialFlowJson.nodes).length : 0,
    });

    editor.fromJSON(initialFlowJson).then(() => {
      const loadedNodes = editor.getNodes();
      logger.debug('Fluxo carregado do JSON (atualização)', {
        nodeCount: loadedNodes.length,
        nodes: loadedNodes.map(n => ({
          id: n.id,
          type: n.data?.type,
          hasComponent: !!n.data?.component,
          hasInputs: !!n.inputs,
          hasOutputs: !!n.outputs,
        })),
      });
    }).catch(err => {
      logger.error('Erro ao carregar fluxo do JSON (atualização)', err);
    });
  }, [initialFlowJson]);

  return (
    <div
      ref={containerRef}
      style={{
        width: '100%',
        height: '100%',
        position: 'relative'
      }}
    />
  );
});
