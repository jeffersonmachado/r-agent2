# Glossário Operacional

Este glossário define a convenção de linguagem preferencial para a documentação canônica do r-agent2.

Princípios:

- Priorizar português em texto corrido.
- Manter alias em inglês entre parênteses quando o termo é padrão técnico do domínio.
- Preservar nomes de endpoint, evento e identificadores técnicos conforme implementados.

## Termos canônicos

| Português (preferencial) | Inglês / Alias | Definição curta |
|---|---|---|
| Evento | Event | Fato operacional observado no runtime. |
| Sinal | Signal | Interpretação operacional de eventos e contexto. |
| Recomendação | Recommendation | Sugestão priorizada de resposta operacional. |
| Decisão | Decision | Escolha explícita de executar, aceitar, ignorar ou rejeitar. |
| Ação | Action | Execução operacional unitária. |
| Ação rápida | Quick Action | Execução operacional de baixa fricção no fluxo de operação. |
| Playbook | Playbook | Sequência orquestrada de ações e regras operacionais. |
| Resultado | Outcome | Evidência observável do efeito da execução. |
| Memória operacional | Operational Memory | Camada de aprendizado com base em resultados e decisões. |
| Próxima Melhor Ação | Next Best Action | Melhor decisão operacional recomendada para o contexto atual. |
| Tempo de execução operacional | Runtime | Camada que executa fluxos, ações e orquestrações. |
| Backbone de eventos | Event Backbone | Espinha dorsal de ingestão e roteamento de eventos. |
| Projeção de estado operacional | Operational State Projection | Estado derivado de eventos para suporte à decisão. |
| Camada de decisão operacional | Operational Decision Layer | Camada que determina a próxima melhor ação. |
| Núcleo operacional | Operational Core | Domínios operacionais centrais (CRM, tickets, agenda, filas etc.). |

## Loop canônico (forma preferencial)

`evento -> sinal -> recomendação -> decisão -> ação/ação rápida/playbook -> resultado -> memória operacional`

## Loop autônomo (forma preferencial)

`observar -> projetar estado -> decidir -> executar -> aprender`

## Componentes arquiteturais

| Termo | Definição curta |
|---|---|
| Backbone de eventos | Camada orientada a eventos que alimenta automações, métricas e decisões. |
| Projeção de estado operacional | Estado derivado de eventos para suporte à decisão. |
| Camada de decisão operacional | Camada responsável por determinar a Próxima Melhor Ação. |
| Runtime de automação | Camada que executa flows, BPMN, playbooks, ações e integrações. |
| Camada de IA | Camada que classifica, recomenda, prevê e enriquece decisões operacionais. |
| Núcleo operacional | Domínios centrais do produto, como CRM, tickets, agenda, filas e pedidos. |
| Template vertical | Especialização da plataforma por vertical, com políticas, automações, métricas e dashboards próprios. |
