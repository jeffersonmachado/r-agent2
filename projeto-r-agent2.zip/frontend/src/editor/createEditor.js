import { NodeEditor } from 'rete';
import { AreaPlugin, AreaExtensions } from 'rete-area-plugin';
import { ConnectionPlugin, Presets as ConnectionPresets } from 'rete-connection-plugin';
import { createRoot } from 'react-dom/client';

import ReactRenderPlugin from '../ReteReactPluginShim';
import { runFlowValidation } from './validation/runFlowValidation';
import logger from '../utils/logger';

/**
 * Cria e configura o editor Rete.js seguindo o padrão do reference.
 * 
 * @param {HTMLElement} container - Container DOM onde o editor será renderizado
 * @param {Object} options - Opções de configuração
 * @param {Object} options.initialFlowJson - JSON inicial do fluxo (opcional)
 * @param {Function} options.onFlowChanged - Callback quando o fluxo muda
 * @param {Function} options.onNodeSelected - Callback quando um nó é selecionado
 * @returns {Promise<{ destroy: () => void, editor: NodeEditor, area: AreaPlugin }>}
 */
export async function createEditor(container, options = {}) {
  const { initialFlowJson, onFlowChanged, onNodeSelected } = options;

  // Criação do editor
  const editor = new NodeEditor();
  
  // Plugins
  const area = new AreaPlugin(container);
  const connection = new ConnectionPlugin();
  const reactPlugin = new ReactRenderPlugin({ createRoot });

  // Configura ConnectionPlugin com preset
  const connectionPreset = ConnectionPresets.classic.setup({ area });
  const connectionPresetValue = typeof connectionPreset === 'function' 
    ? connectionPreset() 
    : connectionPreset;
  connection.addPreset(connectionPresetValue);

  // Configura ReactPlugin com preset customizado
  const reactPreset = ReactRenderPlugin.createPreset(connection);
  const reactPresetValue = typeof reactPreset === 'function' 
    ? reactPreset() 
    : reactPreset;
  reactPlugin.addPreset(reactPresetValue);

  logger.debug('ReactPlugin configurado', {
    hasPlugin: !!reactPlugin,
    hasPreset: !!reactPresetValue,
    presetType: typeof reactPresetValue,
    presetKeys: reactPresetValue ? Object.keys(reactPresetValue) : [],
  });

  // Instala plugins (seguindo o padrão do Rete.js v2)
  editor.use(area);
  area.use(connection);
  area.use(reactPlugin);

  logger.debug('Plugins instalados no area', {
    hasArea: !!area,
    hasConnection: !!connection,
    hasReactPlugin: !!reactPlugin,
  });

  // =========================
  // EXTENSÕES DO AREA (seguindo padrão do reference)
  // =========================
  
  // Seleção de nós (seguindo padrão do reference)
  AreaExtensions.selectableNodes(area, AreaExtensions.selector(), {
    accumulating: AreaExtensions.accumulateOnCtrl(),
  });

  // Ordenação simples de nós (seguindo padrão do reference)
  AreaExtensions.simpleNodesOrder(area);

  // =========================
  // PIPE CANÔNICO DE VALIDAÇÃO (🔥 PRINCIPAL)
  // =========================
  editor.addPipe(ctx => {
    if (
      ctx.type === 'nodecreated' ||
      ctx.type === 'noderemoved' ||
      ctx.type === 'connectioncreated' ||
      ctx.type === 'connectionremoved' ||
      ctx.type === 'imported'
    ) {
      runFlowValidation(editor);
    }
    return ctx;
  });

  // =========================
  // PIPE DE EDIÇÃO DE DADOS
  // =========================
  editor.addPipe(ctx => {
    if (ctx.type === 'nodechanged') {
      runFlowValidation(editor);
    }
    return ctx;
  });

  // =========================
  // PIPE DE MOVIMENTO / SELEÇÃO
  // =========================
  editor.addPipe(ctx => {
    if (ctx.type === 'nodetranslated') {
      onFlowChanged?.(editor);
    }
    return ctx;
  });

  // =========================
  // PIPE DE SELEÇÃO DE NÓS (seguindo padrão do reference)
  // =========================
  area.addPipe(ctx => {
    if (ctx.type === 'nodepicked' || ctx.type === 'nodeselected') {
      const node = ctx.data?.payload || ctx.data?.node;
      if (node && onNodeSelected) {
        // Converte o nó do Rete para formato esperado pelo componente
        const nodeData = {
          id: node.id,
          type: node.data?.type,
          config: node.data?.config || {},
          validationErrors: node.data?.validation?.errors || [],
        };
        onNodeSelected(nodeData);
      }
    }
    if (ctx.type === 'nodeselected' && ctx.data?.payload === null) {
      // Deseleção de nó
      onNodeSelected?.(null);
    }
    return ctx;
  });

  // =========================
  // Carregamento inicial do fluxo (se fornecido)
  // =========================
  if (initialFlowJson) {
    logger.debug('Carregando fluxo do JSON', {
      hasJson: !!initialFlowJson,
      nodeCount: initialFlowJson?.nodes ? Object.keys(initialFlowJson.nodes).length : 0,
    });

    try {
      await editor.fromJSON(initialFlowJson);
      const loadedNodes = editor.getNodes();
      logger.debug('Fluxo carregado do JSON', {
        nodeCount: loadedNodes.length,
        nodes: loadedNodes.map(n => ({
          id: n.id,
          type: n.data?.type,
          hasComponent: !!n.data?.component,
          hasInputs: !!n.inputs,
          hasOutputs: !!n.outputs,
          inputsKeys: n.inputs ? Object.keys(n.inputs) : [],
          outputsKeys: n.outputs ? Object.keys(n.outputs) : [],
          firstInputSocket: n.inputs && Object.values(n.inputs)[0]?.socket,
          firstOutputSocket: n.outputs && Object.values(n.outputs)[0]?.socket,
        })),
      });
      runFlowValidation(editor);
    } catch (err) {
      logger.error('Erro ao carregar fluxo do JSON', err);
    }
  }

  // Retorna objeto com destroy e referências (seguindo padrão do reference)
  return {
    destroy: () => {
      area.destroy();
      editor.clear();
    },
    editor,
    area,
  };
}

