# 06 — Testes

## Estratégia de testes

A estratégia combina cobertura em camadas:

1. **Unitário**: regras de domínio e utilitários.
2. **Contrato/API**: handlers e respostas HTTP.
3. **Integração**: fluxos entre módulos backend.
4. **Frontend**: componentes, hooks e páginas operacionais.
5. **Regressão**: suíte full backend + frontend.

## Comandos principais

### Testes gerais (raiz)

```bash
npm test
npm run test:all
npm run test:complete
```

### Backend

```bash
npm run test:unit
npm run test:flow
npm run test:websocket
npm run test:contracts
npm run test:governance
npm run test:runtime
npm run test:organizational
npm run test:stress
npm run test:rate-limit
```

### Frontend

```bash
cd frontend && npm test
cd frontend && npm run build
```

### Regressão completa

```bash
npm run test:full
npm test
npm run test:system
```

Observação:

- Não existe hoje um script raiz `test:regression:full:no-rpa`.
- Para regressão ampla sem RPA, o comando real é a combinação `npm test` + `npm run test:system`.
- O script `npm run test:full` inclui `test:rpa`.

## Cobertura operacional prioritária

### Backend (ações rápidas e rotas)

- `api/core/operational-quick-actions/__tests__/OperationalQuickActionRegistry.test.js`
- `api/core/operational-quick-actions/__tests__/QuickActionExecutor.test.js`
- `api/core/operational-quick-actions/__tests__/QuickActionAccess.test.js`
- `api/core/operational-quick-actions/__tests__/QuickActionContextGuard.test.js`
- `api/core/operational-quick-actions/__tests__/QuickActionsAPI.test.js`
- `api/core/operational-recommendations/__tests__/OutcomeTrackingService.test.js`
- `api/core/operational-outcomes/__tests__/OperationalOutcomeEngine.test.js`
- `api/server.test.js` (rotas operacionais, auth e guardas)
- `api/core/operational-agent/__tests__/OperationalSignalRegistry.v2.test.js`
- `api/core/operational-state/__tests__/featureGates.test.js`

### Frontend (OCC e recomendações)

- `frontend/src/pages/OperationalControlCenter.test.jsx`
- `frontend/src/modules/recommendations/hooks/__tests__/useQuickActions.test.js`
- `frontend/src/modules/recommendations/components/__tests__/QuickActionsBar.test.jsx`
- `frontend/src/modules/recommendations/components/__tests__/QuickActionButton.test.jsx`
- `frontend/src/modules/recommendations/components/__tests__/QuickActionDialog.test.jsx`

## Boas práticas

- Rodar primeiro o escopo afetado pela mudança (rápido), depois regressão mais ampla.
- Para alterações de ações rápidas (quick actions), validar sempre:
  - listagem por origem (signal/recommendation),
  - execução com payload válido,
  - criação automática de resultado (outcome) + ligação com memória operacional,
  - rejeição de ação inválida,
  - bloqueio por permissão/contexto.
- Não aprovar mudanças operacionais sem cobertura mínima de backend + frontend.

## Critério de pronto para mudanças operacionais

Uma mudança em operação é considerada pronta quando:

- Fluxo funcional validado no escopo alterado.
- Testes automatizados relevantes passam.
- Erros retornam códigos e mensagens consistentes.
- Não há regressão de autorização no escopo admin/contato.

## Validação de consistência de migração (v1 ↔ v2)

O projeto não expõe hoje um script npm dedicado nem o arquivo `scripts/check-operational-state-v2-consistency.js`.

Quando houver rollout de migração operacional, a validação deve ser feita pelos testes automatizados existentes do domínio, principalmente:

- `api/core/operational-state/__tests__/featureGates.test.js`
- `api/core/operational-agent/__tests__/OperationalSignalRegistry.v2.test.js`
- `api/core/operational-agent/__tests__/OperationalCanonicalPipelineService.test.js`
