# Documentação do r-agent2

Este pacote contém a documentação principal de arquitetura, posicionamento e operação da plataforma `r-agent2`.

## Comece por aqui

Os arquivos abaixo formam a trilha principal de leitura para entender o produto como uma **Autonomous Operations Platform para negócios de serviço**:

1. `00-platform-vision.md`
2. `AI-ARCHITECTURE-INDEX.md`
3. `ARCHITECTURE-CONTRACT.md`
4. `ARCHITECTURE-MAP.md`
5. `01-product-positioning.md`
6. `02-core-concepts.md`
7. `03-autonomous-operations-loop.md`
8. `04-architecture-overview.md`
9. `05-operational-brain.md`
10. `06-event-backbone.md`
11. `07-operational-state.md`
12. `08-decision-layer.md`
13. `09-automation-runtime.md`
14. `10-ai-layer.md`
15. `11-operational-core-domains.md`
16. `12-autonomous-scheduling.md`
17. `13-vertical-templates.md`
18. `14-flow-editor-and-automation.md`
19. `15-how-to-align-code-with-architecture.md`
20. `SERVICE_OPERATIONS_KERNEL.md`
21. `09-autonomous-operations-architecture.md`

## Leituras estruturais

### Visão e posicionamento

- `00-platform-vision.md`
- `01-product-positioning.md`
- `POSICIONAMENTO.md`
- `OBJETIVO_FINAL_PLATAFORMA.md`

### Arquitetura conceitual e alinhamento

- `AI-ARCHITECTURE-INDEX.md`
- `ARCHITECTURE-CONTRACT.md`
- `ARCHITECTURE-MAP.md`
- `02-core-concepts.md`
- `03-autonomous-operations-loop.md`
- `04-architecture-overview.md`
- `05-operational-brain.md`
- `09-autonomous-operations-architecture.md`
- `SERVICE_OPERATIONS_KERNEL.md`

### Arquitetura canônica complementar já existente

- `01-overview.md`
- `02-architecture.md`
- `03-operational-model.md`
- `04-api-and-services.md`
- `04-development-rules.md`
- `05-development-guide.md`
- `06-roadmap.md`
- `06-testing.md`
- `07-operational-glossary.md`
- `08-architecture-decisions.md`

## Convenções importantes

- convenção de linguagem e termos operacionais: `07-operational-glossary.md`
- regra fundamental de alinhamento: `event -> state -> decision -> action -> outcome`
- leitura complementar do loop canônico: `evento -> sinal -> recomendação -> decisão -> ação/ação rápida/playbook -> resultado -> memória operacional`

## Observação para agentes de IA

Este projeto não deve ser interpretado como apenas um flow builder, um helpdesk ou um CRM isolado.

A interpretação correta é:

- categoria do produto: `Autonomous Operations Platform`
- arquitetura interna: `Operational Operating System`
- núcleo mínimo comum: `Service Operations Kernel`

Outros documentos nesta pasta podem descrever fases, gaps, análises históricas e implementações parciais. Quando houver dúvida, use os arquivos da trilha principal como fonte prioritária de leitura.
