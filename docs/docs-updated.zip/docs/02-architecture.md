# Arquitetura do r-agent2

## Princípio central

Eventos disparam\
Sinais detectam\
Recomendações sugerem\
Decisão escolhe\
Ações, ações rápidas e playbooks executam\
Resultados medem\
Memória operacional aprende

## Diagrama de arquitetura

``` mermaid
flowchart LR
Events --> Signals --> Recommendations --> Decision --> Actions["Action / Quick Action / Playbook"] --> Outcomes --> OperationalMemory["Operational Memory"]
```

## Interpretação operacional

- `Event`: fato operacional bruto, ocorrência de runtime ou mudança observada
- `Signal`: interpretação operacional de eventos/contexto relevantes
- `Recommendation`: resposta sugerida, priorizada por relevância operacional
- `Decision`: escolha explícita de aceitar, rejeitar, ignorar ou executar
- `Action / Quick Action / Playbook`: camada de execução operacional
- `Outcome`: resultado observável com timestamp, status e rastreabilidade
- `Operational Memory`: aprendizado acumulado a partir de resultados (outcomes), decisões e feedback de recomendações

## Arquitetura de Operações Autônomas

A mesma arquitetura canônica também pode ser interpretada como um sistema operacional de ciclo fechado:

`Observar -> Projetar Estado -> Decidir -> Executar -> Aprender`

Mapeamento entre as duas visões:

- `Observar` corresponde a eventos e fatos operacionais de runtime
- `Projetar Estado` corresponde a projeções/sinais/recomendações sobre o contexto operacional
- `Decidir` corresponde a pontos de decisão explícitos e escolhas de Próxima Melhor Ação
- `Executar` corresponde a ações, ações rápidas, playbooks e execução orquestrada de runtime
- `Aprender` corresponde a resultados (outcomes) e ciclos de feedback da memória operacional

A arquitetura detalhada de componentes desse loop está documentada em `09-autonomous-operations-architecture.md`.

O posicionamento da plataforma e a definição consolidada da categoria do produto estão em `00-platform-vision.md`.

## Componentes principais da arquitetura autônoma

### Event Backbone

O sistema é orientado a eventos. Eventos são insumos de primeira classe para automação, métricas e decisões.

Exemplos:

- `conversation.received`
- `ticket.created`
- `booking.cancelled`
- `booking.gap_detected`
- `contact.reactivation_due`
- `sla.risk_detected`
- `order.delayed`

### Operational State Projections

As projeções de estado derivam dos eventos e consolidam o contexto operacional utilizável pelo sistema.

Exemplos de projeção:

- estado do contato
- estado do ticket
- estado da agenda
- estado da fila
- estado da oportunidade
- estado do atendimento
- estado operacional por profissional/unidade

### Operational Decision Layer

A camada de decisão operacional determina a **Próxima Melhor Ação**.

Exemplos de decisão:

- priorização de ticket
- sugestão de resposta
- reativação de contato
- oferta de horário
- redistribuição de fila
- otimização de agenda
- ações de revenue

### Automation Runtime

O runtime executa decisões usando:

- Flow Editor
- BPMN
- automações
- triggers
- integrações

Modelo:

`Camada de Decisão decide`
`↓`
`Flow / BPMN orquestra`
`↓`
`Serviços executam`

### AI Layer

A camada de IA aplica classificação, RAG, copiloto, geração de resposta, recomendação e previsão sobre dados de:

- CRM
- conversas
- tickets
- agenda
- métricas operacionais

### Operational Core e Vertical Templates

O core operacional concentra:

- CRM operacional
- tickets
- conversations
- scheduling
- queues
- orders
- tasks

Sobre esse núcleo, os templates verticais especializam políticas, pesos, automações, dashboards e métricas para:

- beauty
- fitness
- food
- services
