# How to Align Code with Architecture

## Regra principal

Novos módulos devem seguir, sempre que possível, a sequência:

`event -> state -> decision -> action -> outcome`

## Interpretação prática

- **event**: tornar o fato operacional explícito
- **state**: projetar contexto suficiente para decisão
- **decision**: decidir de forma auditável e explicável
- **action**: executar por runtime, quick action, playbook, flow ou serviço
- **outcome**: registrar o que aconteceu

## O que isso evita

- lógica escondida só na borda HTTP
- automações sem evento claro
- execução sem outcome
- decisões implícitas misturadas com execução
- arquiteturas paralelas fora do modelo operacional

## Checklist para novos módulos

- existe um evento ou fato operacional explícito?
- existe estado projetado suficiente para decidir?
- a decisão está separada da execução?
- a execução produz outcome observável?
- o outcome ou feedback alimenta memória operacional?

## Checklist para refatorações

- a mudança aproxima o módulo do loop `Observe -> Project State -> Decide -> Execute -> Learn`?
- a mudança reduz duplicidade entre decisão e execução?
- a mudança melhora explicabilidade operacional?
- a mudança preserva o ciclo canônico `evento -> sinal -> recomendação -> decisão -> ação -> resultado -> memória`?

## Referências

- visão do produto: `00-platform-vision.md`
- arquitetura geral: `04-architecture-overview.md`
- brain: `05-operational-brain.md`
- backbone de eventos: `06-event-backbone.md`
- estado operacional: `07-operational-state.md`
- decisão: `08-decision-layer.md`
- runtime: `09-automation-runtime.md`
