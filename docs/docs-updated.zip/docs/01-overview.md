# r-agent2 --- Visão Geral

A plataforma r-agent2 é um sistema de inteligência operacional projetado para coordenar operações de relacionamento com clientes.

A plataforma é posicionada como uma **Plataforma de Operações Autônomas para negócios de serviços**, operando como um sistema operacional de ciclo fechado.

Documento-raiz de posicionamento e categoria do produto: `00-platform-vision.md`.

## Arquitetura de Operações Autônomas

O r-agent2 deve ser entendido como uma plataforma que fecha o loop operacional completo:

`Observar -> Projetar Estado -> Decidir -> Executar -> Aprender`

Esse loop convive com o ciclo operacional canônico:

`EVENTO -> SINAL -> RECOMENDAÇÃO -> DECISÃO -> AÇÃO / AÇÃO RÁPIDA / PLAYBOOK -> RESULTADO -> MEMÓRIA OPERACIONAL`

Mapeamento resumido:

- `Observar`: captar fatos operacionais, eventos de runtime e mudanças relevantes do negócio
- `Projetar Estado`: transformar eventos em projeções e contexto de decisão
- `Decidir`: determinar a Próxima Melhor Ação (Next Best Action)
- `Executar`: orquestrar flows, BPMN, automações, quick actions, playbooks e integrações
- `Aprender`: registrar resultados, memória operacional e feedback para o próximo ciclo

Ciclo operacional canônico:

EVENTO → SINAL → RECOMENDAÇÃO → DECISÃO → AÇÃO / AÇÃO RÁPIDA / PLAYBOOK → RESULTADO → MEMÓRIA OPERACIONAL

Foco atual da plataforma:

- detectar e priorizar sinais operacionais
- gerar recomendações com pontos de decisão explícitos
- executar respostas operacionais por meio de ações, ações rápidas ou playbooks
- registrar resultados (outcomes) como evidência operacional canônica
- alimentar a memória operacional com decisões, resultados e feedback de recomendações

## Componentes arquiteturais principais

- `Event Backbone`: backbone orientado a eventos que alimenta automação, métricas e decisões
- `Operational State Projections`: projeções de estado operacional derivadas de eventos
- `Operational Decision Layer`: camada que determina a Próxima Melhor Ação
- `Automation Runtime`: Flow Editor, BPMN, triggers, automações e integrações
- `AI Layer`: classificação, RAG, copiloto, geração de resposta, recomendação e previsão
- `Operational Core`: CRM operacional, tickets, conversations, scheduling, queues, orders e tasks
- `Vertical Templates`: especializações verticais sem alterar o core da plataforma
