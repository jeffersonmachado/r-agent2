# Índice de Documentação — r-agent2

## Trilha principal

1. `00-platform-vision.md`
2. `AI-ARCHITECTURE-INDEX.md`
3. `ARCHITECTURE-CONTRACT.md`
4. `ARCHITECTURE-MAP.md`
5. `01-product-positioning.md`
6. `02-core-concepts.md`
7. `03-autonomous-operations-loop.md`
8. `04-architecture-overview.md`
9. `05-operational-brain.md`
10. `06-event-backbone.md`
11. `07-operational-state.md`
12. `08-decision-layer.md`
13. `09-automation-runtime.md`
14. `10-ai-layer.md`
15. `11-operational-core-domains.md`
16. `12-autonomous-scheduling.md`
17. `13-vertical-templates.md`
18. `14-flow-editor-and-automation.md`
19. `15-how-to-align-code-with-architecture.md`
20. `SERVICE_OPERATIONS_KERNEL.md`
21. `09-autonomous-operations-architecture.md`

## Leitura rápida de posicionamento

- `00-platform-vision.md`
- `01-product-positioning.md`
- `POSICIONAMENTO.md`
- `OBJETIVO_FINAL_PLATAFORMA.md`

## Leitura rápida para IA e alinhamento arquitetural

- `AI-ARCHITECTURE-INDEX.md`
- `ARCHITECTURE-CONTRACT.md`
- `ARCHITECTURE-MAP.md`
- `15-how-to-align-code-with-architecture.md`

## Leituras complementares canônicas

- `01-overview.md`
- `02-architecture.md`
- `03-operational-model.md`
- `04-api-and-services.md`
- `04-development-rules.md`
- `05-development-guide.md`
- `06-roadmap.md`
- `06-testing.md`
- `07-operational-glossary.md`
- `08-architecture-decisions.md`

## Observação

Quando houver conflito interpretativo entre documentos antigos, históricos ou táticos, use a trilha principal acima como referência prioritária para entender o posicionamento e a arquitetura atual da plataforma.
