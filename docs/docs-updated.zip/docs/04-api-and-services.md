# 04 — API e Serviços

## Escopos de API operacional

A plataforma expõe APIs operacionais em dois escopos:

- **Admin/OCC**: gestão e coordenação por tenant.
- **Contato/CRM**: operação contextual para um contato específico.

## Endpoints principais (Admin/OCC)

Base: `api/server.js` + cliente `frontend/src/api/superAdmin.js`

### Saúde e visão OCC

- `GET /api/admin/tenants/health`
- `GET /api/admin/tenant/:tenantId/metrics`
- `GET /api/admin/tenant/:tenantId/alerts`
- `GET /api/admin/tenant/:tenantId/ura/audit`
- `GET /api/admin/tenant/:tenantId/feature-flags`
- `PUT /api/admin/tenant/:tenantId/feature-flags/:featureKey`
- `GET /api/admin/tenant/:tenantId/crm/operational-summary`

### Sinais e recomendações (tenant)

- `GET /api/admin/tenant/:tenantId/operational-signals`
- `POST /api/admin/tenant/:tenantId/operational-signals/generate`
- `POST /api/admin/tenant/:tenantId/operational-signals/:signalId/status`
- `GET /api/admin/tenant/:tenantId/operational-recommendations`
- `POST /api/admin/tenant/:tenantId/operational-recommendations/generate`
- `POST /api/admin/tenant/:tenantId/operational-recommendations/:recommendationId/status`

### API de Resultados Operacionais

- `GET /api/admin/tenant/:tenantId/operational-outcomes`
- Filtros suportados: `status`, `sourceType`, `outcomeType`, `signalId`, `recommendationId`, `playbookExecutionId`, `actionId`, `actionType`, `contactId`, `from`, `to`, `limit`
- Uso principal: OCC, auditoria operacional e análise de aprendizagem

Registro canônico atual:

- ações rápidas (quick actions) registram `OperationalAction` e persistem outcome pela `OperationalOutcomeEngine`
- playbooks registram outcome automático ao completar ou abortar
- mudanças relevantes de recomendação emitem evento operacional e feedback para memória; `accepted`, `ignored` e `executed` passam a ter outcome observável no ciclo operacional
- `OperationalOutcomeEngine` alimenta `OperationalMemoryService.recordOutcome()` automaticamente

Fluxo canônico exposto:

`evento -> sinal -> recomendação -> decisão -> ação -> resultado -> memória operacional`

### Ações rápidas (tenant)

- `GET /api/admin/tenant/:tenantId/operational-signals/:signalId/quick-actions`
- `POST /api/admin/tenant/:tenantId/operational-signals/:signalId/quick-actions/:actionId`
- `GET /api/admin/tenant/:tenantId/operational-recommendations/:recommendationId/quick-actions`
- `POST /api/admin/tenant/:tenantId/operational-recommendations/:recommendationId/quick-actions/:actionId`

### Playbooks (admin)

- `GET /api/admin/playbooks`
- `GET /api/admin/playbooks/:playbookId`
- `POST /api/admin/playbooks/:playbookId/execute`
- `POST /api/admin/playbooks/:playbookId/step`

### CRM Playbooks API

- Endpoint compatível atual: `GET /api/crm/contacts/:contactId/playbooks`
- Alias compatível adicional: `GET /api/operational/crm/contact/:contactId/playbooks`
- Finalidade: listar playbooks sugeridos para um contato a partir de sinais e recomendações operacionais

## Endpoints principais (Contato/CRM)

Base: `api/server.js`

- `GET /api/crm/contacts/:contactId/operational-profile`
- `GET /api/crm/contacts/:contactId/operational-summary`
- `GET /api/crm/contacts/:contactId/operational-signals`
- `GET /api/crm/contacts/:contactId/operational-recommendations`
- `GET /api/crm/contacts/:contactId/operational-signals/:signalId/quick-actions`
- `POST /api/crm/contacts/:contactId/operational-signals/:signalId/quick-actions/:actionId`
- `GET /api/crm/contacts/:contactId/operational-recommendations/:recommendationId/quick-actions`
- `POST /api/crm/contacts/:contactId/operational-recommendations/:recommendationId/quick-actions/:actionId`

## Catálogo de serviços de domínio

## Registro de rotas operacionais

Base de registro:

- `api/routes/index.js`
- `api/bootstrap/registerRoutes.js`
- `api/routes/operationalOccRoutes.js`
- `api/routes/operationalSupportRoutes.js`
- `api/routes/crmRoutes.js`
- `api/routes/whatsappRoutes.js`
- `api/server/healthRoutes.js`
- `api/server/marketingPublicRoutes.js`
- `api/server/pbxCoreRoutes.js`
- `api/server/pbxMediaRoutes.js`
- `api/server/publicMediaRoutes.js`
- `api/server/provisioningPublicRoutes.js`
- `api/server/systemRoutes.js`

Organização atual:

- OCC por domínio em `api/routes/occ/`
- Support/operational em `api/routes/support/`
- CRM operacional por contato em `api/routes/crmRoutes.js`
- WhatsApp com orquestrador fino em `api/routes/whatsappRoutes.js`
- Subdomínios de WhatsApp em `api/routes/whatsapp/`
  - `whatsappWebhookRoutes.js`
  - `whatsappQrRoutes.js`
  - `whatsappIvrRoutes.js`
  - `whatsappTemplateRoutes.js`
  - `whatsappShared.js`
- `api/routes/index.js` hoje despacha grupos reais para `admin`, `operational`, `support`, `crm` e `whatsapp`
- `admin` já cobre a borda HTTP de `rate-limit`, `super-admin/tenants`, métricas por tenant, bloqueio/desbloqueio, ajuste de plano e feature flags/auditoria operacional
- `whatsapp` já cobre a borda HTTP de webhooks, IVR, templates e QR connections/runtime, preservando os mesmos endpoints públicos
- `api/server/healthRoutes.js` concentra `GET /health`, `GET /health/live`, `GET /health/db`, `GET /health/ready`, `GET /ready`, `GET /health/selftest`, `GET /selftest` e `GET /version`
- `api/server/marketingPublicRoutes.js` concentra o marketing público `GET /mkt/track.js`, `POST /mkt/e`, `GET /mkt/l/:code`, `GET|POST /mkt/click`, `GET /lp/:slug` e `POST /lp/:slug/submit`
- `api/server/pbxCoreRoutes.js` concentra o núcleo de configuração PBX em `GET|POST /api/pbx/extensions`, `POST /api/pbx/extensions/bulk`, `GET|POST /api/pbx/provisioning-token*`, `GET /api/pbx/audit`, `GET|POST|DELETE /api/pbx/acls`, `GET|POST /api/pbx/trunks`, `GET|POST /api/pbx/routes`, `GET|POST /api/pbx/dids`, `GET|POST /api/pbx/call-rules`, `GET|POST /api/pbx/queues`, `GET /api/pbx/queues/metrics`, `POST /api/pbx/dialplan/*`, `GET /api/pbx/config-versions`, `POST /api/pbx/reload` e `GET|POST|DELETE /api/pbx/queue-members`
- `api/server/pbxMediaRoutes.js` concentra `GET /api/pbx/audio-assets`, `POST /api/pbx/audio-assets/upload`, `GET /api/pbx/audio-assets/file`, `GET /api/pbx/recordings`, `GET|POST /api/pbx/recordings/policy`, `POST /api/pbx/recordings/scan`, `GET /api/pbx/recordings/file` e `GET /api/pbx/cdr`
- `api/server.js` ainda mantém rotas históricas extensas, mas o domínio PBX agora está separado entre `pbxCoreRoutes` e `pbxMediaRoutes`, além das rotas públicas de mídia em `api/server/publicMediaRoutes.js`
- `api/server/publicMediaRoutes.js` hoje concentra `GET /public/support-media/:tenant/:filename` e `GET /public/whatsapp-media`
- `api/server/provisioningPublicRoutes.js` concentra `GET /provision/:tenantKey/:vendor/:mac` e `GET /provision/:tenantKey/:token/:vendor/:mac`
- `api/server/systemRoutes.js` concentra os endpoints estruturais `GET /system/status`, `GET /system/websocket` e `GET /server/process-manager`

Os endpoints públicos permanecem os mesmos; a divisão acima é apenas organizacional.

### `api/core/operational-agent/`

- `OperationalAgentService`: orquestra visão operacional integrada.
- `SignalDetectionService`: detecta sinais ativos.
- `OperationalSignalRegistry`: catálogo e regras de sinais.
- `OperationalContextAssembler`: monta contexto operacional unificado.
- `OperationalRecommendationScorer`: scoring operacional complementar.

### `api/core/insights/RecommendationEngine.js`

- Geração e priorização de recomendações a partir de contexto/sinais.

### `api/core/operational-quick-actions/`

- `OperationalQuickActionRegistry`: define ações e mapeamentos.
- `QuickActionAccess`: resolve permissão e escopo de execução.
- `QuickActionContextGuard`: valida pré-condições contextuais.
- `QuickActionExecutor`: executa ação e registra outcome.

### `api/core/operational-playbooks/`

- `OperationalPlaybookEngine`: seleciona e inicia playbooks.
- `PlaybookRegistry`: catálogo de playbooks.
- `PlaybookRunner`: ciclo de execução.
- `PlaybookStepExecutor`: execução de cada etapa.

### `api/core/operational-outcomes/`

- `OperationalOutcomeEngine`: registro e consulta de outcomes operacionais.
- `OutcomeTrackingService`: rastreio de quick actions; persiste `OperationalAction` e delega o outcome à engine canônica.

### `api/core/operational-memory/`

- `OperationalMemoryService`: persistência operacional compatível para outcomes, decisões e feedback de recomendações.
- Consultas principais: `getRecentOperationalLearnings()` e `getOutcomeStats()`.

## Contratos operacionais mínimos

Em respostas operacionais, manter consistência de campos-chave:

- Identificação: `id`, `tenantId`, `contactId` (quando aplicável)
- Classificação: `type`, `status`, `priority`/`score`
- Contexto: `context`/`context_json`
- Auditoria: `createdAt`, `updatedAt`, `executedBy`/`actor` (quando aplicável)

## Regras de integração

- Todo endpoint operacional requer autenticação.
- Escopo admin e escopo contato não devem ser misturados no mesmo fluxo de UI.
- Quick actions devem retornar erro explícito para ação inválida/sem contexto.
- Mudanças em contratos devem ser refletidas em testes de API e frontend.
- Outcomes devem alimentar memória operacional automaticamente.
