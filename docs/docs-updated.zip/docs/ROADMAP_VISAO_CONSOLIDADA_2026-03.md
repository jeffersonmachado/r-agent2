# Roteiro consolidado — r-agent2 (Roadmap)

## Visão

O r-agent2 evolui de plataforma de atendimento para **Customer Operating System (COS)** / **Plataforma de Operações Autônomas para negócios de serviços**.

## Pilares

1. Plataforma de Automação
2. CRM Operacional Integrado
3. Contact Center Omnichannel (Atendimento Omnichannel)
4. Agendamento (Scheduling)
5. Operações Autônomas (Autonomous Operations)
6. Operações Preditivas (Predictive Operations)
7. Motor de Receita (Revenue Engine)
8. Canais Físicos (Kiosk)
9. Templates Verticais

## Benchmarks por pilar

- Automação: n8n, LangFlow, Flowise
- CRM/Marketing: HubSpot, RD Station
- Atendimento: Zendesk, Blip, Huggy
- Agendamento (Scheduling): Calendly, Fresha
- Operações Autônomas (Autonomous Operations): Mindbody, Fresha (referência parcial)
- Kiosk/Fila: Qminder, QLess, Waitwhile, McDonald's (UX)
- Food: iFood, Uber Eats, Rappi, DoorDash
- Serviços de Campo (Field Service): Housecall Pro, Jobber

## Verticais oficiais

- Beauty
- Fitness
- Food
- Prestadores de Serviços
- Services (consultoria, clínica, etc.)

## Próximas fases

### Fase 1 — Runtime operacional do core
- `autonomous_runtime`
- feature flags por tenant
- quiet hours
- limites por rodada
- segurança de execução

### Fase 2 — Operações Preditivas (Predictive Operations)
- risco de ociosidade (idle risk)
- risco de no-show
- probabilidade de preenchimento (fill probability)
- recomendações preventivas

### Fase 3 — Motor de Receita (Revenue Engine)
- oportunidades de receita (revenue opportunities)
- reativação
- upsell / cross-sell
- otimização leve de precificação

### Fase 4 — Kiosk / Smart Lobby
- check-in
- fila
- autoatendimento
- agendamento imediato
- integração com agenda autônoma

### Fase 5 — Templates verticais robustos
- beauty
- fitness
- food
- services

## Próximo passo recomendado

Implementar o **runtime operacional por tenant** e a **camada de métricas operacionais agregadas**, porque esses dois blocos sustentam previsão, automação recorrente, motor de receita e kiosks.
