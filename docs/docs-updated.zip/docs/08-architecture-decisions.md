# Decisões de Arquitetura

ADR-001 Sinais para detecção operacional

ADR-002 Camada de recomendação

ADR-003 Motor de decisão

ADR-004 Ações rápidas e playbooks pertencem à mesma camada de execução do ciclo operacional canônico

ADR-005 O rastreamento de resultados (outcomes) é a camada canônica de evidência da execução operacional

ADR-006 A Memória Operacional é alimentada por resultados, decisões e feedback de recomendações, não apenas por artefatos conversacionais

ADR-007 A plataforma é documentada como um sistema operacional de ciclo fechado

ADR-008 Backbone de eventos e projeções de estado operacional são componentes de primeira classe da arquitetura

ADR-009 A Camada de Decisão Operacional determina a Próxima Melhor Ação e delega a execução ao Runtime de Automação

ADR-010 Agendamento Autônomo é o primeiro domínio operacional autônomo implementado na plataforma
