# Playbook de Rollback — Suítes Críticas (Orders / Fast Service / PBX)

## Objetivo
Padronizar rollback operacional para as suítes críticas com evidências mínimas de execução.

## Pré-check geral
1. Confirmar incidente e janela de rollback.
2. Executar snapshot/backup antes de alterar estado:
   - `bash scripts/backup-postgres.sh`
3. Registrar início no incidente com data/hora e responsável.

## Suite: Orders/Delivery
1. Validar saude atual:
   - `curl -s http://localhost:3000/health/selftest`
2. Reverter ultima mudanca de configuracao/flow da suite (deployment ou publish anterior).
3. Executar smoke mínimo:
   - criar pedido publico
   - validar status kitchen/dispatch
4. Evidências:
   - logs da API
   - payload do smoke
   - status final de `/health/selftest`

## Suíte: Fast Service (Filas físicas)
1. Reverter configuracoes da fila/unidade para versao estavel.
2. Executar smoke mínimo:
   - kiosk cria ticket
   - station faz call/start/finish
   - panel reflete fila
3. Evidências:
   - respostas HTTP dos endpoints publicos
   - screenshot/registro de panel

## Suíte: PBX/Voz
1. Reverter dialplan/config para versao anterior.
2. Validar integridade PBX:
   - `bash scripts/test-pbx-realtime.sh`
3. Validar runtime de voz:
   - `node scripts/test-voice-runtime-smoke.js`
4. Evidências:
   - output do smoke PBX
   - output do smoke de voz
   - `/health/selftest` sem `FAIL`

## Restore/DR básico (quando necessário)
1. Restaurar backup:
   - `bash scripts/restore-postgres.sh`
2. Reexecutar migrações/boot se aplicável:
   - `npm run db:migrate`
3. Validar import/export de backup por API:
   - `GET /api/backup/export`
   - `POST /api/backup/import`

## Gate de encerramento
1. Executar gate de release:
   - `npm run system:release-gate`
   - padrao: `RELEASE_GATE_MODE=stack` (executa `npm run test:websocket` + stack completa)
   - opcional diagnostico: `RELEASE_GATE_MODE=legacy npm run system:release-gate`
   - validacao isolada da regressao websocket: `npm run test:websocket`
2. Executar simulado de rollback e gerar evidência:
   - `npm run system:rollback-drill`
   - opcional (aplica rollback PBX no drill): `ROLLBACK_DRILL_APPLY_PBX=1 npm run system:rollback-drill`
   - por padrão, o drill exige evidência PBX de `L-03`/`L-04` em `qa/smoke-evidence.json` (`ROLLBACK_DRILL_REQUIRE_PBX_SMOKE_EVIDENCE=1`).
   - para diagnóstico isolado (sem smoke prévio): `ROLLBACK_DRILL_REQUIRE_PBX_SMOKE_EVIDENCE=0 npm run system:rollback-drill`
3. Consolidar decisão técnica de liberação:
   - `npm run system:go-no-go`
   - execução rápida sem rerodar suites pesadas: `GO_NO_GO_RUN_RELEASE_GATE=0 GO_NO_GO_RUN_ROLLBACK_DRILL=0 npm run system:go-no-go`
   - relatório: `qa/go-no-go-report.json`
4. Atualizar checklist executivo de marcos do lançamento:
   - `npm run system:launch-plan-status`
   - saídas: `qa/launch-plan-status.json` e `qa/launch-plan-status.md`
5. Arquivar evidências:
   - `qa/release-gate-report.json`
   - `qa/rollback-drill-report.json`
   - `qa/go-no-go-report.json`
   - `qa/launch-plan-status.json`
   - `qa/launch-plan-status.md`
   - `qa/release-window-report.json`
   - `qa/release-manifest.json`
   - `qa/release-summary.md`
   - pacote consolidado: `npm run system:release-evidence-pack`
     - dry-run de validação: `RELEASE_EVIDENCE_DRY_RUN=1 npm run system:release-evidence-pack`
     - integridade: validar `SHA256SUMS` dentro da pasta `qa/release-evidence/<timestamp>/`
     - verificação automática: `npm run system:release-evidence-verify`
     - retenção/limpeza (recomendado após handoff): `RELEASE_EVIDENCE_PRUNE_KEEP=5 RELEASE_EVIDENCE_PRUNE_DRY_RUN=0 npm run system:release-evidence-prune`
    - logs operacionais
    - checklist de rollback preenchido

## Atalho de contingência (automatizado)
1. Rodar fluxo consolidado de contingência:
   - `npm run system:release-contingency`
2. Opções úteis:
   - sem backup (quando já existe snapshot externo): `RELEASE_CONTINGENCY_RUN_BACKUP=0 npm run system:release-contingency`
   - apenas validação de pipeline (dry-run): `RELEASE_CONTINGENCY_DRY_RUN=1 npm run system:release-contingency`
3. Evidência:
   - `qa/release-contingency-report.json`

## Execução padronizada da janela (recomendado)
1. Modo rápido de validação (sem rerodar suites pesadas):
   - `RELEASE_WINDOW_FAST=1 npm run system:release-window`
2. Modo completo para a janela oficial:
   - pre-check: `npm run system:release-clean-check`
   - `npm run system:release-window`
   - opcional (já limpar snapshots antigos ao final): `RELEASE_WINDOW_PRUNE_OLD=1 npm run system:release-window`
   - observação: o modo full já executa `system:checklist` em modo estrito (`CHECKLIST_REQUIRE_LAUNCH_EVIDENCE=1`)
3. Evidência consolidada da execução:
   - `qa/release-window-report.json`
   - `qa/release-manifest.json`
   - `qa/release-summary.md`
