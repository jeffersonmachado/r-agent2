# Regras de Desenvolvimento

- Endpoints devem ser enxutos.
- A lógica de negócio deve viver em serviços.
- O estado operacional deve ter uma única fonte de verdade.
