# Roteiro (Roadmap)

1 Base operacional
2 Detecção de sinais
3 Recomendações
4 Motor de decisão
5 Ações rápidas
6 Playbooks
7 Motor de resultados
8 Camada de contexto
9 Memória operacional
10 Refinamento de inteligência

## Leitura do roadmap pela arquitetura autônoma

O roadmap acima corresponde à evolução do loop:

`Observar -> Projetar Estado -> Decidir -> Executar -> Aprender`

Mapeamento:

- `Observar`: base operacional + backbone de eventos
- `Projetar Estado`: detecção de sinais + camada de contexto + projeções de estado
- `Decidir`: recomendações + motor de decisão
- `Executar`: ações rápidas + playbooks + runtime de automação
- `Aprender`: motor de resultados + memória operacional + refinamento de inteligência

## Primeiro domínio autônomo implementado

O primeiro domínio já materializado nesse roadmap é **Agendamento Autônomo (Autonomous Scheduling)**:

`booking.cancelled -> detecção de lacuna -> geração de candidatos -> ranking -> campanha/oferta -> agendamento confirmado`
