# Guia de Desenvolvimento

Backend:

api/ core/ services/ routes/ db/

Frontend:

frontend/src/ modules/ pages/ components/
