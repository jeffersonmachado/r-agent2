import React from 'react';
import { PropertyField, TextField, TextAreaField, JsonField } from './components/PropertyField';
import { getNodeSchema, getNodeProperties } from './editor/nodeSchemas';

/**
 * Painel lateral de propriedades do nó selecionado - estilo moderno
 * 
 * Usa schema centralizado (nodeSchemas.js) para obter metadados e propriedades
 */
export function SidebarProperties({ selectedNode, onChangeConfig }) {

  if (!selectedNode) {
    return (
      <div className="w-80 border-l border-border-default p-8 text-sm bg-gradient-to-br from-bg-secondary to-bg-tertiary flex flex-col items-center justify-center text-text-tertiary">
        <div className="text-center space-y-3 max-w-[240px]">
          <div className="text-4xl mb-3 opacity-40">📋</div>
          <div className="text-base font-semibold text-text-secondary mb-1">
            Nenhum nó selecionado
          </div>
          <div className="text-xs text-text-tertiary leading-relaxed">
            Clique em um nó para ver e editar suas propriedades.
          </div>
        </div>
      </div>
    );
  }

  const { id, type, config = {}, validationErrors = [] } = selectedNode;

  // Obtém schema do nó do schema centralizado
  const nodeSchema = getNodeSchema(type);
  const icon = nodeSchema?.icon || '●';
  const label = nodeSchema?.label || type;
  const description = nodeSchema?.description || 'Nó do fluxo de conversa.';
  const color = nodeSchema?.color || '#ffffff';

  // Obtém propriedades do schema
  const properties = getNodeProperties(type);

  const updateConfigField = (field, value) => {
    onChangeConfig({
      ...config,
      [field]: value,
    });
  };

  const updateJsonField = (field, rawValue, expectedType = 'object') => {
    try {
      const defaultEmpty = expectedType === 'array' ? '[]' : '{}';
      const parsed = JSON.parse(rawValue || defaultEmpty);
      updateConfigField(field, parsed);
    } catch {
      // Mantém o valor raw para permitir edição incremental
      // A validação será feita pelo JsonField
    }
  };

  return (
    <div className="w-80 border-l border-border-default p-5 text-sm bg-gradient-to-b from-bg-secondary to-bg-tertiary flex flex-col gap-5 overflow-y-auto scrollbar-thin scrollbar-thumb-border-default scrollbar-track-transparent">
      {/* Cabeçalho com ícone, tipo e descrição */}
      <div
        className="p-5 rounded-xl border backdrop-blur-sm shadow-lg transition-all duration-300"
        style={{
          background: `linear-gradient(135deg, ${color}18 0%, ${color}10 100%)`,
          borderColor: `${color}35`,
        }}
      >
        <div className="flex items-center gap-3.5 mb-3">
          <div
            className="w-12 h-12 rounded-xl flex items-center justify-center text-2xl flex-shrink-0 shadow-lg backdrop-blur-sm transition-transform duration-200"
            style={{
              backgroundColor: `${color}25`,
              boxShadow: `0 4px 12px ${color}30`,
            }}
          >
            {icon}
          </div>
          <div className="flex-1 min-w-0">
            <div
              className="text-lg font-semibold mb-1 truncate"
              style={{ color }}
            >
              {label}
            </div>
            <div className="text-[11px] text-text-tertiary uppercase tracking-wider font-mono opacity-80">
              {type}
            </div>
          </div>
        </div>
        <div
          className="text-xs text-text-secondary leading-relaxed pt-3 border-t"
          style={{
            borderTopColor: `${color}25`,
          }}
        >
          {description}
        </div>
      </div>

      <div className="p-3.5 rounded-lg bg-bg-tertiary/60 border border-border-default/60">
        <div className="text-[10px] text-text-tertiary mb-2 uppercase tracking-wider font-semibold">
          ID do nó
        </div>
        <div className="font-medium text-text-primary font-mono text-xs break-all leading-relaxed">{id}</div>
      </div>

      {/* Erros de validação do nó selecionado */}
      {validationErrors.length > 0 && (
        <div className="p-3.5 rounded-lg bg-bg-tertiary/60 border border-status-error/60 space-y-2">
          <div className="flex items-center justify-between">
            <div className="text-[10px] text-status-error mb-1 uppercase tracking-wider font-semibold">
              Problemas de validação
            </div>
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-status-error/10 text-status-error font-mono">
              {validationErrors.length}
            </span>
          </div>
          <ul className="space-y-1.5 m-0 p-0 list-none text-[11px] text-text-secondary">
            {validationErrors.map((err, idx) => (
              <li key={`${err.code}-${idx}`} className="flex flex-col">
                <span className="font-mono text-status-error font-semibold">
                  [{err.code}]
                </span>
                <span className="leading-snug">{err.message}</span>
              </li>
            ))}
          </ul>
        </div>
      )}

      {/* Nó Anterior */}
      <div className="p-3.5 rounded-lg bg-bg-tertiary/60 border border-border-default/60">
        <div className="text-[10px] text-text-tertiary mb-2 uppercase tracking-wider font-semibold">
          Nó Anterior
        </div>
        <div className="font-medium text-text-primary font-mono text-xs break-all leading-relaxed">
          {selectedNode.previousNodeId || (
            <span className="text-text-tertiary italic">Nenhum</span>
          )}
        </div>
      </div>

      {/* Nó Próximo */}
      <div className="p-3.5 rounded-lg bg-bg-tertiary/60 border border-border-default/60">
        <div className="text-[10px] text-text-tertiary mb-2 uppercase tracking-wider font-semibold">
          Nó Próximo
        </div>
        <div className="font-medium text-text-primary font-mono text-xs break-all leading-relaxed">
          {selectedNode.nextNodeId || (
            <span className="text-text-tertiary italic">Nenhum</span>
          )}
        </div>
      </div>

      {/* Renderiza propriedades dinamicamente baseado no schema */}
      {properties.length > 0 ? (
        <div className="space-y-4">
          {properties.map((prop) => {
            const value = config[prop.key] ?? prop.defaultValue ?? '';
            
            if (prop.type === 'text') {
              return (
                <TextField
                  key={prop.key}
                  label={prop.label}
                  description={prop.description}
                  value={value}
                  onChange={(e) => updateConfigField(prop.key, e.target.value)}
                  placeholder={prop.placeholder}
                  required={prop.required}
                  className={prop.key === 'variable' || prop.key === 'outputVariable' ? 'font-mono' : ''}
                />
              );
            }
            
            if (prop.type === 'textarea') {
              return (
                <TextAreaField
                  key={prop.key}
                  label={prop.label}
                  description={prop.description}
                  value={value}
                  onChange={(e) => updateConfigField(prop.key, e.target.value)}
                  placeholder={prop.placeholder}
                  required={prop.required}
                  rows={prop.rows || 4}
                />
              );
            }
            
            if (prop.type === 'json') {
              return (
                <JsonField
                  key={prop.key}
                  label={prop.label}
                  description={prop.description}
                  value={value ? JSON.stringify(value, null, 2) : ''}
                  onChange={(rawValue) => {
                    if (prop.expectedType === 'array') {
                      updateJsonField(prop.key, rawValue, 'array');
                    } else {
                      try {
                        const parsed = rawValue.trim() ? JSON.parse(rawValue) : null;
                        updateConfigField(prop.key, parsed);
                      } catch {
                        // Mantém raw para edição incremental
                      }
                    }
                  }}
                  placeholder={prop.placeholder}
                  required={prop.required}
                  rows={prop.rows || 8}
                  expectedType={prop.expectedType || 'object'}
                />
              );
            }
            
            return null;
          })}
          
          {/* Ajuda adicional para router */}
          {type === 'router' && (
            <div className="p-3 rounded-md bg-bg-tertiary/30 border border-border-default/30">
              <div className="text-[10px] text-text-tertiary uppercase tracking-wider font-medium mb-1.5">
                Operadores de Condição
              </div>
              <div className="text-[10px] text-text-secondary space-y-1">
                <div><code className="text-accent-primary">"op": "always"</code> - Sempre verdadeiro (fallback)</div>
                <div><code className="text-accent-primary">"op": "contains"</code> - Verifica se variável contém valor</div>
                <div><code className="text-accent-primary">"op": "equals"</code> - Verifica igualdade exata</div>
              </div>
            </div>
          )}
        </div>
      ) : (
        /* Fallback para nós sem propriedades (start, end) */
        <div className="space-y-4">
          {(type === 'start' || type === 'end') && (
            <div className="p-3 rounded-md bg-bg-tertiary/30 border border-border-default/30">
              <p className="text-xs text-text-secondary leading-relaxed">
                {type === 'start' 
                  ? 'Este é o nó inicial do fluxo. Não requer configuração adicional.'
                  : 'Este é o nó final do fluxo. Encerra a conversa quando alcançado.'}
              </p>
            </div>
          )}
          {Object.keys(config).length > 0 && (
            <JsonField
              label="Configuração Avançada"
              description="Configuração customizada em formato JSON. Use apenas se necessário."
              value={JSON.stringify(config, null, 2)}
              onChange={(rawValue) => {
                try {
                  const parsed = JSON.parse(rawValue || '{}');
                  onChangeConfig(parsed);
                } catch {
                  // Mantém raw para edição incremental
                }
              }}
              rows={6}
              expectedType="object"
            />
          )}
        </div>
      )}
    </div>
  );
}


