# Pilares e benchmarks — visão revisada

## Leitura arquitetural consolidada

Os pilares abaixo devem ser lidos dentro da arquitetura de operações autônomas:

`Observar -> Projetar Estado -> Decidir -> Executar -> Aprender`

Mapeamento:

- `Plataforma de Automação` -> `Runtime de Automação`
- `CRM Operacional Integrado` -> `Núcleo Operacional`
- `Atendimento Omnichannel` -> `Núcleo Operacional`
- `Agendamento` -> `Núcleo Operacional`
- `Operações Autônomas` -> `Camada de Decisão Operacional`
- `Operações Preditivas` -> `Camada de IA`
- `Motor de Receita` -> `Camada de Decisão Operacional + Camada de IA`
- `Kiosk / Autoatendimento` -> `Núcleo Operacional`
- `Templates verticais` -> `Templates Verticais`

## 1. Plataforma de Automação
Benchmark: n8n

Capacidades:
- runtime DAG
- agendador
- fila
- replay
- subfluxos
- templates

## 2. CRM Operacional Integrado
Benchmarks: HubSpot, RD Station

Capacidades:
- contatos
- leads
- pipelines
- atividades
- analytics

## 3. Atendimento Omnichannel (Contact Center Omnichannel)
Benchmarks: Zendesk, Blip, Huggy

Capacidades:
- WhatsApp
- chat
- tickets
- bots
- agentes

## 4. Agendamento (Scheduling)
Benchmarks: Calendly, Fresha

Capacidades:
- disponibilidade
- bloqueios
- lembretes
- reagendamento
- políticas

## 5. Operações Autônomas (Autonomous Operations)
Benchmarks conceituais: Mindbody, Fresha

Capacidades:
- detecção de lacunas
- ranking de candidatos
- lista de espera
- motor de campanhas
- booking automático
- métricas operacionais

## 6. Operações Preditivas (Predictive Operations)
Sem benchmark único dominante.

Capacidades:
- risco de ociosidade
- risco de no-show
- probabilidade de preenchimento
- campanhas preventivas

## 7. Motor de Receita (Revenue Engine)
Benchmarks indiretos: HubSpot, Mindbody, Toast

Capacidades:
- detecção de oportunidades
- reativação
- upsell
- retenção
- sugestões de precificação

## 8. Kiosk / Autoatendimento
Benchmarks: Qminder, QLess, Waitwhile, McDonald's (UX)

Capacidades:
- check-in
- fila virtual
- autoatendimento
- pedido
- agendamento
- pagamento

## 9. Templates verticais
### Beauty
- recorrência curta
- manutenção
- lista de espera forte

### Fitness
- lead→avaliação→matrícula
- retenção

### Food
- pedidos
- fila de preparo
- retirada / delivery

### Prestadores de Serviços
- visita técnica
- orçamento
- ordem de serviço
